Q. ERYTHRINAE–E. VARIEGATA MEROPS MANUSCRIPT RELEASE

Snapshot date: 12 September 2026
Status: FROZEN CURATED-V2 ANALYSIS SNAPSHOT

This directory is a copy-only manuscript snapshot of the authoritative
MEROPS version-2 analysis. Original project files remain in the active
qe_merops_screen project.

Scientific scope:
* Secreted inhibitor-family homologues in Q. erythrinae
* Galled-petiole-upregulated secreted peptidase homologues in E. variegata
* Cross-species juxtaposition of candidate programmes

Interpretive boundary:
This analysis does not identify direct plant–insect protein pairs and does
not demonstrate biochemical inhibition or molecular interaction.

Authoritative headline sets:
* 149 curated A+B insect secreted inhibitor-family candidates
* 9 Pfam-supported larva-up I01/I04/I19 candidates
* 68 pupa-up secreted inhibitor-family candidates
* 93 curated A+B plant peptidase candidates
* 20 manuscript-priority plant peptidase candidates

The full MEROPS database is not duplicated here. Database checksums,
inventory records and DIAMOND database information are provided under
08_database_metadata.

Files in 05_membership_provenance are v1 baselines retained only for
version-2 membership-change accounting. They are not current biological
candidate tables.

Only files in 01_curated_results should be used for quantitative manuscript
reporting.
