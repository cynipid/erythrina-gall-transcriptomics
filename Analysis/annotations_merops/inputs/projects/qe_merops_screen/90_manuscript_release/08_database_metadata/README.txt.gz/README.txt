MEROPS DATABASE METADATA

The full MEROPS source library, DIAMOND-cleaned FASTA and DIAMOND database
are intentionally not duplicated in this compact manuscript snapshot.

MEROPS_database_manifest.tsv records their authoritative active-tree paths,
sizes and SHA-256 checksums. The original and cleaned FASTA checksum files
are also retained here.

diamond_dbinfo.txt records the DIAMOND database type, format, sequence count
and total residue count.

Authoritative active-tree locations:

00_database/pepunit.lib
00_database/pepunit.diamond_clean.faa
02_diamond_db/merops_pepunit.dmnd

The cleaned FASTA and DIAMOND database each contain 1,227,939 sequences.
